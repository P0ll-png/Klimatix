'use client'

import 'leaflet/dist/leaflet.css'
import L from 'leaflet'
import { MapContainer, Marker, TileLayer, useMapEvents } from 'react-leaflet'

const CENTER: [number, number] = [14.5995, 120.9842]
const pin = L.divIcon({ className: 'report-location-pin', html: '<span></span>', iconSize: [28, 28], iconAnchor: [14, 28] })

function Picker({ value, onChange }: { value: [number, number] | null; onChange: (value: [number, number]) => void }) {
  useMapEvents({ click(event) { onChange([event.latlng.lat, event.latlng.lng]) } })
  return value ? <Marker position={value} icon={pin} draggable eventHandlers={{ dragend(event) { const position = event.target.getLatLng(); onChange([position.lat, position.lng]) } }} /> : null
}

export default function ReportLocationMap({ value, onChange }: { value: [number, number] | null; onChange: (value: [number, number]) => void }) {
  return <MapContainer center={CENTER} zoom={12} scrollWheelZoom className="report-location-map h-48 w-full rounded-xl"><TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" attribution="© OpenStreetMap contributors" /><Picker value={value} onChange={onChange} /></MapContainer>
}
